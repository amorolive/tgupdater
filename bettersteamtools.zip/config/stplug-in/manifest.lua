function fetch_manifest_code(gid)
    -- Запрос к вашему прокси-воркеру
    local url = "https://steamrun.amorolive.ru/" .. tostring(gid)
    local body, st = http_get(url)
    
    if st == 200 and body then
        -- API steam.run возвращает JSON вида {"content":"123456789..."}
        local code = body:match('"content"%s*:%s*"?(%d+)"?') or body:match("^%s*(%d+)%s*$")
        if code then
            return tostring(code)
        end
    end

    -- Запасной вариант на случай сбоя
    local backup_url = "http://wudrm.amorolive.ru/" .. tostring(gid)
    local b_body, b_st = http_get(backup_url)
    if b_st == 200 and b_body then
        local code = b_body:match('"content"%s*:%s*"?(%d+)"?') or b_body:match("^%s*(%d+)%s*$")
        if code then
            return tostring(code)
        end
    end

    return nil
end

function fetch_manifest_code_ex(app_id, depot_id, gid)
    return fetch_manifest_code(gid)
end