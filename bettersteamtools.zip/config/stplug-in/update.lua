--# 105600 - Terraria
-- Main AppID
addappid(105600)
-- Main Depots
addappid(105601, 1, "612f916fe8230616a9c57a1da6e8ae2b642833ef5074b36be5fa7c8515d7155d") -- (windows)
addappid(105602, 1, "15da89575c5f9ae52e76cacec4f912f9fb3b4f1c152f88b03a14b9acf1c1a173") -- (linux)
addappid(105603, 1, "a735ff57e669edad75db38c477a9e732f87fb05c824da7cd842712e07e9e51d9") -- (macos, 64-bit)

--# 107410 - Arma 3
-- Main AppID
addappid(107410)
-- Main Depots
addappid(107411, 1, "833b10a4156402ff5a874c5fe740af6294d055f92fc25c69607b3351ffbfe679") -- (windows)
addappid(107413, 1, "44faf57ebfee712ae9316d3f7ec77e3a763190dc8325e63cc8aa23235718f798") -- (windows)
addappid(107414, 1, "9e0b330c18485bdf6a3444b5ec24c0f56f2234669f54ba15d8640af0b62fa9d3") -- (windows)
addappid(107415, 1, "74e3e7e31e761aa6fa007fc703408e88a980512d3bc0f737c2b724bcef1ccc38") -- (windows)
addappid(107416, 1, "748d4dde34f8d535cfc2306c110fd9646c6644d814c0fff1dc853dd70953b353") -- (windows)
addappid(107417, 1, "9ebe30dbeca6377c4d81a2d7b181eb449164ac5b9975f02c12efeb808af3b7f1") -- (windows)
addappid(107418, 1, "b20b8b302fd775dd5f510f4c6d92303e5e9e91a5c1dd63b49d5fba5c73a16e15") -- (windows)
addappid(107419, 1, "ae1c1fd9b03805ae6f6e4a1d1356142422c19353b5acc12ede23ad710b1a4ed2") -- (windows)
addappid(107420, 1, "721d759ad3199299425a057d3075e0bf1078ea624d65faae71bd11254617a966")
addappid(107421, 1, "965c797f05169d0a632cea851fab1d418d19ba8557a54af8f32667658782dca1") -- French
addappid(107422, 1, "5dc537b4337aaafa4d100493e59e8a7ee84cbcedb16777622685a2047d91a306") -- German
addappid(107423, 1, "4a4d56da6c332cd0be710e0e7b3117dab1f73ed51810d800a7e747011ab69a85") -- Italian
addappid(107424, 1, "f9348a2559cf47ded3a0f49e4dcb54281587c1f5725499091856cf1866c49fba") -- Spanish
addappid(107425, 1, "398f6319a28f9570857894591a9c2e2168669f521529f30bc42d00b73b9a89dc") -- Czech
addappid(107426, 1, "6c45afa220059d2deb0b16d7ee972cc58e158f8e55b885bf09296867ba76e3ab") -- Russian
addappid(107427, 1, "2e127da445a329f971cb2da6f95a042f20ea9b14829fb74179f34841e710a815") -- Polish
addappid(107428, 1, "055d57fcc12ff12b49a329f177eba80af24ec36b377ba03148e2d9d4172effa7") -- Brazilian
addappid(107429, 1, "5f3b60be0c035cec10f8fb64490071b14f4a6ca0375f7495e2b2dab864f8904c") -- Koreana
addappid(249501, 1, "37f6a5a690ef6ecccf4eb4197d2256b611bf80cc95338ff552f8f09c100086a5") -- Japanese
addappid(249502, 1, "277ba94f2fa9a7f293ee635051aecd51bf5b7580fbde96927600d9f9f7fdf903")
addappid(249504, 1, "7a5c9a04f58f3f86cbdef4e9f2817629d08bbf84a1f4321e13f917f6e92887d6") -- (windows)
addappid(249505, 1, "f77130c5d488aced7c009e872beb263ef9a845463aed4372c5968c310cc6565a") -- (macos)
addappid(249506, 1, "720c4414485a1bd6aad38fb825f7455fc6f41d61176a6eab369d339a64601ff5") -- (macos)
addappid(249508, 1, "f384303deb8d08f3dcadcf71d670a0bae23e6e46f72b2e9426152a725c48a40b") -- (macos)
addappid(249510, 1, "af7b2fba5a503e59c847039be22b27bde7385d837b8a4211cb46d77e70715022") -- Schinese
addappid(249511, 1, "cfd49c5a7dd4d67a3cebfaa501b735cef12ca4dbca4e21e5fe5df3984a4fe7c3") -- Tchinese
addappid(249512, 1, "e88d176e948e932b3f6682bc73e9836ee83bfbdb65ca649efdbc49e833c1cdc5") -- Turkish
addappid(249860, 1, "b1d6aa1d14f16b1f383aec21c0931c12832a42239eb026f5afaa6d8e970de449")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

--# 1086940 - Baldur's Gate 3
-- Main AppID
addappid(1086940)
-- Main Depots
addappid(1086941, 1, "4876e089a6bb7a4d8da586306d4040c7d4bd5fb7c05da6c5441a760aa0b2bef6") -- (windows)
addappid(1086942, 1, "5313c9d372b30e73c15606d9792e5f23314c21559d35f54eb7b5e8369e28b036") -- English (windows)
addappid(1086943, 1, "8e611b984e4bee3d57f719cb5f73a69d2935cd826ab0cef2185e5d3bfe0dc272") -- French (windows)
addappid(1086944, 1, "c5ba980103bb168497ff98d0faca3bdef34d8328098d43aee0dce6461468daa6") -- German (windows)
addappid(1086945, 1, "5bfe4c9e909a98b53a970a1cab2bc67cafdea68b169c3f585b8b3b0762282b74") -- Polish (windows)
addappid(1086946, 1, "febd9048a518edadea98e5c5daa5cbaf3e9e0e5920154007f97111cbf487ef52") -- Russian (windows)
addappid(1086947, 1, "1e9c89eb1395c0ae168407fbcf33ea43b0f8937033d45485ee2a17737bd6beeb") -- Schinese (windows)
addappid(1086948, 1, "0b7198f84d1c683b5c4670d13cbad273d50896bb16424423814d15a4be629923") -- Tchinese (windows)
addappid(1086949, 1, "2bd5f702d5349ecff8f4d5a2d575c883939b435d0081671954314a093a24acd4") -- Spanish (windows)
addappid(1419650, 1, "8ff19ec3475e30f649dbd9afdeec7805c60162b66d348bf06fe9b0ebf31f8095") -- Italian (windows)
addappid(1419651, 1, "cb6dcb0c6b59caa4d14f208f4c91dda0db49dcb244487f8d2939e4d0df1a0fa2") -- Turkish (windows, 64-bit)
addappid(1419652, 1, "43c13e12030aed1fdb00bd1c630bd68f0d22cb23289c879b00d7904aa05fcc89") -- (windows)
addappid(1419653, 1, "dc9bee49d256e78104b71d0bf90e9818631b069dce3b576a86fa6345d3b94896") -- (windows)
addappid(1419657, 1, "93e82e826849110eafaab1cbce34013b629c83ae54b721b04bd63972768f5864") -- Turkish (macos)
addappid(1419658, 1, "78d07ca5c99bdbaba2167c7c6fbe4ebae6ed0abb76e65e207209cce9eff9d084") -- Brazilian (windows)
addappid(1419659, 1, "6cb8cd5bf7992d1a73f8c457ee5f5ee287b01822132084291522c132ebea1f6e") -- Koreana (macos)
addappid(1419660, 1, "d43be075ab476e7f895098958154afeb0c5982041685354104a4bf8347df1f48") -- (macos)
addappid(1419661, 1, "f0abb3e52786d3d5d6c0788d8e5fe6855b1520f5034d75618265726a370cc3ce") -- English (macos)
addappid(1419662, 1, "d692cbc14df4524227c601f481987bec2c22bcf56a944040ed254405b4f3bb95") -- French (macos)
addappid(1419663, 1, "4ff33f8dbf2f891668d22bd1260f2bdaf5900124c67995c506265695ade438bd") -- German (macos)
addappid(1419664, 1, "00d4de0f8f717ab8a08bbb01a737d9af341c164d9f5c44b840ec3e6235852fe9") -- Russian (macos)
addappid(1419665, 1, "473f4742a5cf82f9ba639d7e657c84e116493b30b0e7aa8be56cc7bbb297b391") -- Polish (macos)
addappid(1419666, 1, "08c2d7418efd3e58ff1d2d7ebbb5b5f6e86a1756093b3ac1fec27bdf6b5a12f8") -- Spanish (macos)
addappid(1419667, 1, "d20164301f37c4ff691e7f9e5881cfa57ef7f65447ec317fd3098594c08cd8ee") -- Schinese (macos)
addappid(1419668, 1, "abd8a66e97a01588a93c4e77a4a246a771b76b15db1c16e2a08bc2870f587819") -- Japanese (windows)
addappid(1419669, 1, "9bcfd7785faa9f9c46555e4c214e8d4a3445e88d3ba8708e3717c6078fc38801") -- Koreana (windows)
addappid(2330350, 1, "e29448a5a803bac897d89c21a54271b93cad4793263caeae3e19c0b963524614") -- Ukrainian (windows)
addappid(2330351, 1, "00106a111eb560b12b684a5b635d7966762ac65f3b3830ddc40b7b09febc82ae") -- Latam (windows)
addappid(2330352, 1, "e7f759c9f39f104d8f5bb49153caac2195d006bb4f23b40254199f16ecd8cfc6") -- Tchinese (macos)
addappid(2330353, 1, "f74356cba683ca39ecc7d21a5853bf3b6571875c0dc058ab0ecfb817c9a9d41e") -- Italian (macos)
addappid(2330354, 1, "5b198327f5564ecfc10d6151138f69c766456916feb7958a363ab3959aff9de2") -- Ukrainian (macos)
addappid(2330355, 1, "69df36ae1000c3da76a7a4b0dad51657dc450a972e53f1fef589df34e48a0885") -- Latam (macos)
addappid(2330356, 1, "05ab4c7489dac005d12b294f688338c89699983da4003781842e4669d7201331") -- Brazilian (macos)
addappid(2330357, 1, "31db647b6387beb2f8b15ee459b6e1c99c3e935108209edf3c40c0ac327759b1") -- Japanese (macos)
addappid(2330359, 1, "2bede26d81b7fe150b073f04a95733e1377000d00bdc8e08ca8de665ecf4a082") -- (linux)
addappid(2378501, 1, "f0f133d646308c77d52f6e88b456946322b6aae5ca5a35ff3ff6130664e37838") -- (linux)
addappid(2378503, 1, "de057f959221009e3a900f7d33a1f53c8cedc7baeab7508acab681927e3d81e8") -- English (linux)
addappid(2378504, 1, "0a420360dd2456b671470e2f185302ff348a4ccf34a09593e2e084a5b9671429") -- French (linux)
addappid(2378505, 1, "371fe64c652717475e28ae5379b4c1b20470fa048ccaced97b2252041f2aa87b") -- German (linux)
addappid(2378506, 1, "d599bf1a2f0ae979c23dc6454de009fd2c030ac365c76c833b7cc485e7b443ae") -- Italian (linux)
addappid(2378507, 1, "1e08bd9184e734f38e2fa9bcc9feb90d25ad74f0c12691b02fe86fa1219228a5") -- Polish (linux)
addappid(2378508, 1, "b5eadec11dfc10648adf712733b76a8c63a1f8bf33fd1eedcf69326681bc9633") -- Russian (linux)
addappid(2378509, 1, "5881ff4e584a83d684b3854ac059e5889e7448a6fdbf420cb6f23d1f35f4584f") -- Schinese (linux)
addappid(2378511, 1, "db11319fe425485132079fd1f19daf3ef691637d3535537e6f6cb5c4f1a4c46b") -- Tchinese (linux)
addappid(2378512, 1, "5b55082029f179a949f8b7a729dd648033cb1450027a7d806afa9656a9f9bb3a") -- Spanish (linux)
addappid(2378513, 1, "aa77fbcb4e88742e3e6e4c8765aa03cf3c6e2eb04e819771dd5e12b822a97316") -- Turkish (linux)
addappid(2378514, 1, "c29e2661c5dbc9b7b014208fa2eacd775a4b8b360fcf577ada7d38688df0ca41") -- Japanese (linux)
addappid(2378515, 1, "b81aab9f1a0a751bed094fa1bb5a47b3ef796bc61d19381f67be2a22c8fc1f1e") -- Koreana (linux)
addappid(2378516, 1, "74ee8561a8a00645daa5ecce5ee5a09cf2415ff664aa00d1fe9cc28279621cdb") -- Ukrainian (linux)
addappid(2378517, 1, "4f5c5a2a9d700ffadd349c67364ec78029c48057194bd5a4a177a40145e0df41") -- Latam (linux)
addappid(2378518, 1, "d6e9dfc242a95a4cd44bf29dc01ec12b9dbad4533cdab9de47c98f30b8d34c56") -- Brazilian (linux)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

--# 1091500 - Cyberpunk 2077
-- Main AppID
addappid(1091500)
-- Main Depots
addappid(1091501, 1, "fd4524cb30582752f15e4bf01254dbb7b890f58008101a40208cd78fb139d800") -- (windows)
addappid(1091502, 1, "90dd5a17a45ff0595a7ed6366d0fea078e8c362633ebbe6382c173d736063b72") -- Polish (windows)
addappid(1091503, 1, "b2606cbfc79b86f848e75dbf59afeeae8a1d5c08523111dcdbeace51b69ec48c") -- Russian (windows)
addappid(1091504, 1, "c874647c72c73e87686ecef42bd4c0fbc8e564be98bb0c20c487807c2c4d8d47") -- French (windows)
addappid(1091505, 1, "8382ac2e50bd6c716f748eefe9aa9a7e4ccafe5f4f2d7a19f01e5d5d2d096864") -- Italian (windows)
addappid(1091506, 1, "794d47675f8d91a58528e4b7e0bb347d1c542ccdd48eeda5a796b7c1af663e08") -- German (windows)
addappid(1091507, 1, "ad400264d25291632ad0c35e48e98ae3ada3c411a7ed946bacbdfaa80fd0dd00") -- Spanish (windows)
addappid(1091508, 1, "fa0ebf333c7ac4828a8a38fd9c646543a872965d3bf1b5e205fa176dc1e93337") -- Japanese (windows)
addappid(1091509, 1, "987c3b4b920a2258661e62065089d398fcc2412b300355c47a2655b4b373fafa") -- Schinese (windows)
addappid(1460470, 1, "97d6dfacfdc6ba0678277cfbdc4f38b561807a3fb8679513411c7b9e819195b3") -- Koreana (windows)
addappid(1460471, 1, "20f9808b7948ce1d4b7b16d660e745ce5f251bd0e40c18d8a4072d7f944eb56e") -- Brazilian (windows)
addappid(1460472, 1, "4a09fae0555b97d34d444aedd46d8cd47c11ab25628c614721745c8a3a849c67") -- (macos)
addappid(1460473, 1, "64626ac37340f33f4b81bb2c265d17c61f4fad0b9563bb7b203043296046d2e6") -- Polish (macos)
addappid(1460474, 1, "99ea9ff03413e3248190086be885c4d1737381b7f0f556a1a454cdf978e6c920") -- Russian (macos)
addappid(1460475, 1, "fb5c6a7f869e491c703a7f492c9ade3fe005c518641889a62b16bc6906f799dc") -- French (macos)
addappid(1460476, 1, "61fdd193af9b99cedd7e906207aa0226e707f8284c65bd101c576e1d76271f7a") -- Italian (macos)
addappid(1460477, 1, "7d2ad45d3773bf1408ae5c1a830316b4b8e9642ddac137a9f6c222621b922127") -- German (macos)
addappid(1460478, 1, "a2da1ad1617b6d8f0063b3d7e1bfd3a05a7f1fd2c52ec2ae6143de6a1b30144d") -- Spanish (macos)
addappid(1460479, 1, "7f2d2390ec4b34101279050df7906f9cdb6945d65cb83d41406b90efc6d4820b") -- Japanese (macos)
addappid(2060311, 1, "ef94a15784ab7bc81ddec255b4f2af287543f9dd64edc1210faa708302ef4644") -- Schinese (macos)
addappid(2060312, 1, "f41e81056d725072d0a92b750b9f7156fc37d87f82cec6b5cc9a6e1907c25724") -- Koreana (macos)
addappid(2060313, 1, "e4840e97b028bf1877c6173d714b377621610d8caba91bf5077da9ce6758ae43") -- Brazilian (macos)
addappid(2060314, 1, "ff813dcc60265582f65f61e4ab399689124c32d7147dc5add8ccc9cb3077310e") -- (macos)
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

--# 1144200 - Ready or Not
-- Main AppID
addappid(1144200)
-- Main Depots
addappid(1144201, 1, "b9236894ba071d12dd117ce16220fefeb20574d7c6f7d2170e3113346867f3d6") -- English (windows, 64-bit)
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

--# 1172620 - Sea of Thieves
-- Main AppID
addappid(1172620)
-- Main Depots
addappid(1172621, 1, "d0a7c81c3c4ec69d5646531c500f6f8e46c7a42a74c6baf68a210c8db2f82117")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

--# 1238810 - Battlefield V
-- Main AppID
addappid(1238810)
-- Main Depots
addappid(1238811, 1, "7271dde6918406c6d85c6bb7a4b1445e0c39c9c2a10a6a4fc40cc1c5034c774a")
addappid(1238812, 1, "0523a08b011e472da981321449f4dd0fddf89e2e021c806ee7e32504437c100e") -- English
addappid(1238813, 1, "9828e66572dbb34fdb84625660c194a7d805a0665d88d4691aa85740d62ea718") -- French
addappid(1238814, 1, "a72306efce63de26f5086cb44339d50331891f072fda6c686e919496c41211ea") -- German
addappid(1238815, 1, "bd0096b1350ca6efbb761a6fa00bc13622b14c0b7d9ea0a9442456190ccbcb2f") -- Spanish
addappid(1238816, 1, "81a7d6f82a3e0fef1ccf48dcb4cd52b3c9d1b403f6ca535a913ec763b8bbdc76") -- Italian
addappid(1238817, 1, "ed0fd93b52120ed0750d84399c54b6c8df2bd092e427b3a25f3681dc3755507a") -- Russian
addappid(1238818, 1, "419aedfbebf515490a1a8da77df1fc650cc074ea73f24c9413123942cb8343ff") -- Polish
addappid(1238819, 1, "54fc167de029c497af84d15e1267a8783eab472f9cd3951da1d6c5836daf6653") -- Japanese
addappid(1254583, 1, "8772e7d481fae4c8fc944cb674af3388208d28e061165f14ec233693d517651f") -- Tchinese
addappid(1254584, 1, "cbf97b8608a9ac634d01aeace9b029ba74ee7fa015499a1cb2c4210822fb4983") -- Schinese
addappid(1254585, 1, "b3ce07efc7b1c7ce7fe09e2ef9a563cec7f7972be95e3483f9773a4c5d1da39b") -- Brazilian
addappid(1254586, 1, "2b59a1686c87c60ba2b9028cdd3457a86b1872ceae988a2929cc2b5a47173970") -- Latam
addappid(1254587, 1, "59a3a36a5add4b37b4f21e266622d7c4a88d7e512cf0bc8bdffed4866727743b") -- Arabic
addappid(1254588, 1, "cfee412ddf5154c1ddf30ed4cea51d36180406740e7ea8d313d15ba175839b32") -- Koreana
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
addappid(3893181, 1, "7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6")

--# 1422450 - Deadlock
-- Main AppID
addappid(1422450)
addtoken(1422450, "2775941950181063242")
-- Main Depots
addappid(1422451, 1, "5e41412d5525ec19c3b35b0e7394dd394f3afe8a0a40d308fddf6486c5d5f19a")
addappid(1422452, 1, "cec8fb9b3514cdd7394110792bcfdb6b07903f136c0df1f81d7b94b02dc6ca89") -- (windows)
addappid(1422456, 1, "e615f3146e84f310bda59c806c74be74c86d1b81aa2b143e8e00a414ac279868")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

--# 1517290 - Battlefield 2042
-- Main AppID
addappid(1517290)
-- Main Depots
addappid(1517291, 1, "d7387ee0dddd7c974afd4dbea141d732c7c5735adfaad640ab2f77f09322cdd9")
addappid(1517293, 1, "cbe5726b835cf8743d85912cfbe5f3c2cf1bedd9bf9a4f2997c93eb07854fd12") -- English
addappid(1517294, 1, "69eff46c1cc1b1e7e53e4f9a1e1f75d5bf7a9c7eadff409d84c4e2fb63e2948e") -- German
addappid(1517295, 1, "0f222b93595feee49c428b381111635a26e7d528ed294582000a10ce66a767e6") -- French
addappid(1517296, 1, "4be4d9436a3b9c871f32dd778c47ba6148be6056fb68b17888f087bea24e3d25") -- Italian
addappid(1517297, 1, "5aacbe0cf3444e0efad51866a7c595b5f9cd98069e1fad94e7011d207c005995") -- Koreana
addappid(1517298, 1, "f080b1a6ee49ac607d69e076cf7985906b3185de7cb17170aa4357f8a84847fa") -- Spanish
addappid(1517299, 1, "cb7d068c172a90d88b96d96ddf6b69a441e071002e07245731a92d6173799e46") -- Schinese
addappid(1635824, 1, "644ba5588b91f0be1bc52cada432c9b9a417483cfb3063e126f256540b0e495f") -- Tchinese
addappid(1635825, 1, "f2f1e1800233411e270e9b043acefd16da1836298a1e86566e509974f6795950") -- Russian
addappid(1635826, 1, "0449fa7616acbb56c6e334a618e4f116bdd1abbd3a70d45f384ccd41520862a6") -- Japanese
addappid(1635827, 1, "3e5984f4c57ae39864ee01ae51e9a1f0bccf0e0f268e521e92782fe6eedb8968") -- Polish
addappid(1635828, 1, "2b9a42b5aced127f92556699e869ba2d45d691d15116ce156141f27ad48046fe") -- Arabic
addappid(1635829, 1, "66c9664d1b543723a6900a9ca8499167e077f904036cbe2108dcce073ff9a2c6") -- Brazilian
addappid(1696392, 1, "222b4859c49ace01d42a76bdb760b7aadee98f183f496e8465b0b6dfa6c87eeb") -- Latam
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
addappid(3893181, 1, "7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6")

--# 1551360 - Forza Horizon 5
-- Main AppID
addappid(1551360)
-- Main Depots
addappid(1551361, 1, "13b42353469d4bb26905e2c12e73d4cd63ad89c21f438b3cf5b4b9a9bb659227")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
--# 1808500 - ARC Raiders
-- Main AppID
addappid(1808500)
addtoken(1808500, "7256239618080054575")
-- Main Depots
addappid(1808501, 1, "9f7c91d4609594120c713e82bb64d0ebf15c63fdf6887bc2b3f8f20fcf58e005")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

--# 2073850 - THE FINALS
-- Main AppID
addappid(2073850)
-- Main Depots
addappid(2073851, 1, "0ac69706a0ad749c7111eeb755df5595603cd8ba035b220276b7f32bca7a9e99")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

--# 2183900 - Warhammer 40,000: Space Marine 2
-- Main AppID
addappid(2183900)
addtoken(2183900, "12779763340560861411")
-- Main Depots
addappid(2183901, 1, "8df236a6a5084039477362b31157e7e0eb66554a744762d6782c544ab64d0c4e")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

--# 218620 - PAYDAY 2
-- Main AppID
addappid(218620)
-- Main Depots
addappid(218621, 1, "2d0de203756909d9b2b65506594648ce773a0428741fcae5208616bd9c79d3ea") -- (windows)
addappid(218623, 1, "125afa058982488c55e77fc1ed4e1a4f160786f8383db3db5ed5510d760611b6") -- Russian
addappid(218624, 1, "deab327ada094059df67910f69c19cfffeb79aff089df65433f1760ad23bf639") -- Dutch
addappid(218625, 1, "af7ebe5bfa557f52f7d9993481d10385f5eb32adf77936bc8d9a4f66a9d80fdc") -- French
addappid(218626, 1, "90e5e5d05e46661b2c26e7194d6531796a4017bca0f5e5900cd79f01dd45537b") -- German
addappid(218627, 1, "5baf56fb99687983be6e6c22a7be8889468866a4eda552bbe3dc5ffc212081b7") -- Italian
addappid(218628, 1, "bf4eac2b5b55bdc1264f00e3f24193e6c82c01284b02f3af2137ab8915211e86") -- Spanish
addappid(218629, 1, "26cbf329bd73db8f9e7beefe23857b1e0c76b3aef5d3e9e4e6b5b3f31be0ddc5") -- Japanese
addappid(218631, 1, "1c394d148b286577ab96453164cb03ded6619ccfad3da0f01aac23d71302d1e2") -- Schinese
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)

--# 220 - Half-Life 2
-- Main AppID
addappid(220)
-- Main Depots
addappid(221, 1, "f5e105e91fb4354535c3cf3c8951788ab552be70223608c6694363a226133b85")
addappid(222, 1, "3ab884cba0fadaca0c1fd679674ded49751376c9d31601cbf5024df1f82d4506") -- (windows)
addappid(223, 1, "9bdd77e77514c4ab1868ccf58a8d8664e65f69ecbe2cfb770769034477b8c86e") -- (macos)
addappid(224, 1, "918d917917c2b39588108c8009673f885025a339340afc19a5ef1941d5925595") -- (linux)
addappid(225, 1, "60e635e4daf91e2fd671ffc26e4941dab0988ae3f3a2328dfc04ffe4117e26b5") -- Russian
addappid(226, 1, "1bd20044a82e9539ac742ac3691df05152904d82342d9255f45b52c0c57e54c6") -- Spanish
addappid(227, 1, "f6aa27353df328897edbd51b5a825d70f7c358807397a93eb5abfcb94b183572") -- French
addappid(228, 1, "d75d5d119b336a64745a13676bd7006d972c3de556e771e0009661ff7d4dd955") -- German
addappid(229, 1, "18ca38da67160ae26a413b19f3f9b43dacb40373d5327f676a4278aa32e26203") -- Koreana
addappid(230, 1, "ea712d5794d15e57eb2ba5ba0b5ecf3341086b43701e6e6973ff92ddf03de683") -- Tchinese
addappid(231, 1, "c25bd10ea1f4d8727710046873443ff79da609575d5d5e98450334c9fb3a98a6") -- Schinese
addappid(232, 1, "894ec100daaf7781542c2fa06826fe7b1f22fa4ab74b8a61bf23da586ee42367") -- Italian
addappid(233, 1, "4c903543278080fadf911204001bb474a80561a9c74b66138e327b84ad28e769")
addappid(234, 1, "5daa4d2379f218e856f6d8c7ef665d6d70887883f4ca9cd3afbd10d1fe2ec2d0")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(340, 1, "6d5c26d8f32759026b5e035e7c1b7bd372918becec852b6ca14897215d96ad21")
addappid(341, 1, "b1ecfe9865c3c7f4b38e95f78fb4f0598ccb241c80f0807c4a77c4a4f90c8fb0") -- French
addappid(342, 1, "52cf71d5565827f8909429a2ace5696a5b82ddad568fb805c98690a1c5a0f5a4") -- German
addappid(343, 1, "2412a0a1ef3d7364d72d5b0d923447bcb95bd30fbcdeaa872936da60b0c8422b") -- Russian
addappid(344, 1, "87b42652fa48ca6646de63aeca37589717d5db46659d42449b0d9e1225f89558") -- Spanish
addappid(345, 1, "692d691055830dd04b3cddcc1a7bf9d5621b09a9269ba5fa2458cee493567acd") -- Italian
addappid(346, 1, "ccd14320e7e90a810f3b0088e5fff475747ff5c8972239b4b10effdb47213cf7") -- Koreana
addappid(347, 1, "41d9664bf0b420e947409d9e4713e6bc92eea588ee26933c9775d6ca1bdcdfd1") -- Schinese
addappid(348, 1, "5f822c359d28f01a58cc40326cc2e9359da0cab42ac3636942eb27d42b82bce2") -- Tchinese
addappid(380, 1, "c7483771aa5cabfa034d86283a17438be34dd95bd3acb5ecc02bf62e527389e4")
addappid(381, 1, "43cbfef04a73172acde761eb5dfcd8d4ae0a78e6069a5cc5740f83dfb9f352f8") -- French
addappid(382, 1, "d93a483c0da0814e1da42efc92e12f380240561dc3ff6c017716823795d35d1c") -- German
addappid(383, 1, "0887582dc2d4bd92c677b3f22cc2e28bb2066c0c00392413f9fcc2fa90a7b43f") -- Russian
addappid(384, 1, "27ad5f59a417b17931dfc8b56de22c57060ae041d012382a7dfc8b6b9a1ecb24") -- Spanish
addappid(385, 1, "1d4e92908733db38cbb6a98ecccf19bfd3c90247d20b14a666aa57da0f36e37a") -- Koreana
addappid(386, 1, "17cd02472abe276543703bd06c6ef27b5b888135b3fada6b539e6ccbf8761ec7") -- Tchinese
addappid(387, 1, "697c041290f422d01b2e6ec9a77ed1228bb8aea7b8ce4bb7656db4d43cacc3c6") -- Schinese
addappid(388, 1, "8e8fa5db2868d729aeaa092613da7f511d219b2a93c486ec5cb9fd0812d9c998") -- Italian
addappid(389, 1, "e8a443d7ad9e767467e32e045d3f57cebe75478eb4faec1ea9f36f098df236c8")
addappid(420, 1, "efa23c50d649235917d96f24e2f8734c7a3197fc5fe1c4a7ad5c966b2a884a16")
addappid(421, 1, "5afe8a6d938c98a0e2d90a41456af70491194fc5f6b5260a6f3bed29373c7429") -- French
addappid(422, 1, "e2b5824301e9bd1543eaf2c562f72f5316b49a4dbc32e60490f1bdffd7a0706e") -- German
addappid(423, 1, "ad29ddede5c35a594e2c05fbd58f8d2632076af98a998dd0b2364cc797319287") -- Russian
addappid(424, 1, "e3d554af58e735c2ae0e2ff4e56cddac154795786f969d1fd69790d93daa90be") -- Spanish

--# 221100 - DayZ
-- Main AppID
addappid(221100)
-- Main Depots
addappid(221101, 1, "9d9c5d3d77309bbe701a3f018cea877d22d07160b4ea2b65bdf261d0dc399c15")
addappid(221102, 1, "fe6ef04ad5778ee58766d4c8b7057fa84feb52c2cc0155d808fb40ca1bd42789") -- (windows, 64-bit)
addappid(221103, 1, "8c293c78a93710624b59e6876c06cc38e2d27a96b389eda6b977ebca95fbb9dc")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

--# 240 - Counter-Strike: Source
-- Main AppID
addappid(240)
-- Main Depots
addappid(209, 1, "65597f95b601e6c3f4b97d9044ab4c12ac772121cb0c7fb6c09495881e6421c6")
addappid(240, 1, "0b9b5cccf29f318ed834567beb6a8fae80f4cea166dfb0b56814337dc3bff9ee")
addappid(241, 1, "d07ffb24e34c3b78dd848ab86e57b6bdd1977062c6fec53f9f32b2a3285096da")
addappid(243, 1, "d976afda521b9dc2524e5cf43335f62ea5ebf4b5999ab2d9e5bff6122f6e1f19") -- French
addappid(244, 1, "9a6218cef94f81f0447ce533721ccf993254118ac92a0b26bd2ded4d5781d467") -- Italian
addappid(245, 1, "6dd908eb13ff887a70e5241cd8f784d8af9a07cef0d27571cb784396c7da6885") -- German
addappid(246, 1, "52fef06ff9ee94cb9e0ea67a839bea714a3918f4f9b3a7b2976a9a3b178b6f8e") -- Spanish
addappid(247, 1, "e454424da3658a49af32bdc85b4a22ca8deb1bb206d653f095d19bcccd26df1c") -- Schinese
addappid(249, 1, "372d8ebbf841bb65d036bb5d7b35dd1412761d4cc9a004d40e81ea61bbff204e") -- Koreana
addappid(250, 1, "9ee3ba74a8485d8d5895407a0cd2391bce7597f4fb8a89f8fcd0f9237aabc9a3") -- Tchinese
addappid(251, 1, "d851fe3ec76f099d11ccc77a7ef4fa1a54216ec6b215b36ca43112afc4141a12") -- Japanese
addappid(252, 1, "8a511c5321a1b95615de0de04b328c355cfc53fbd77f4aba0d3be774ff6dc610") -- Russian
addappid(253, 1, "6396e7ad5e36503e7f4f48108d324ec8e94e8c397b21110107e20bd0e37653cd") -- Thai
addappid(232331, 1, "54199e376bd48ed470f028a662aff042826c9ffbba7ef90f4dcbd6a50bda0bd2") -- (windows)
addappid(232332, 1, "56750a1d7fa95694087e431b4d8cf2e142ab06d767a25c33813c77526c2c94ca") -- (macos)
addappid(232333, 1, "2a8061ebc8ef4cc51cfdf4b0a2597d079fba1c06b769457f3fdb466e76020011") -- (linux)

--# 2456740 - inZOI
-- Main AppID
addappid(2456740)
-- Main Depots
addappid(2456741, 1, "e91cba2d1d471bdfb115bee76ac997858f84e6ab0a82af5f17d0054f8a3c9686") -- (windows)
addappid(2456742, 1, "7c9a756f88682f7ae0913792f29b1c2ad7c702cb41859ecb9965e8c8760aff0d") -- (macos, 64-bit)
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

--# 252490 - Rust
-- Main AppID
addappid(252490)
-- Main Depots
addappid(252492, 1, "96b750328197855f4311ba6ad6d86e9051866cc6b9a6c851de55cc41b8ad9a24") -- (macos)
addappid(252494, 1, "5d5f72c0460cb7598666696c1b2f612f22efb43fb87cf4322e596bfec8a231ec")
addappid(252495, 1, "728fcdc1c6af4454f3c86e5bc62a75875af5ba790cc8a2623620e216086e034d") -- (windows, 64-bit)
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)

--# 252950 - Rocket League
-- Main AppID
addappid(252950)
-- Main Depots
addappid(252951, 1, "2c5162dd5164c160a18d4a0086a9a540bf27b1879d0a0e7c69e2d5e0b287e681") -- (windows)
addappid(252952, 1, "e07657ba2a95aa1599fee2e0dc27f86d21c280c6e36295d61a10478251efbd80") -- Japanese
addappid(252953, 1, "82fe5333148dc6dadd932dd622d8594a3f2cfbc96bdc5dd70a2261ebb90f2c69") -- French
addappid(252954, 1, "706ffd8207c3bf1bf598421fd53ae108587bcf77f03cd5be2d1bd03e510aacf7") -- Italian
addappid(252955, 1, "9cdc308ddc198a1176112ee82dec8c39c35d412a638ea50ffddaec6bb9c112ae") -- German
addappid(252956, 1, "ed2bc8a848fd33009e08cf5ab297e2530dcf0605e33d2b072e4d8b68ef75da24") -- Spanish
addappid(252957, 1, "0ac63ca60da191510247cf382fdbf94bae44000450557b658a7f93b49fb4457b") -- Dutch
addappid(252958, 1, "fbd245fd77848586642e8c5c02b0478a4810b4e895edbddd11e8771f6a637ed0") -- Portuguese
addappid(252959, 1, "93c5d4454fc08a119685a61c5b02af961a183eefa3550a67b5c64a8b1170d205") -- Koreana
addappid(252960, 1, "0729c40cd6ccb20223e55f65ff65e386c7ddbe91b91ea3eb3d56d2634e3c6543") -- Turkish
addappid(252961, 1, "97fc37ccba41374f4d55ae03feeeb2144def3f55ece0856e41f6162a730a81f5") -- (linux)
addappid(252962, 1, "112d4200f836026eaa24f3ac6ff4c405dada93daa3779ab92e3dd387693c1dbb") -- Russian
addappid(252963, 1, "176b94925a2f7f9452c7089ffb870f53bdb9564c993deb43d1cadbc3beedc6b8") -- (macos)
addappid(252964, 1, "fa024050d977900bd48d5c3e9968694a8161d792487375b1c9ee8944b679c583") -- Polish
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

--# 271590 - Grand Theft Auto V Legacy
-- Main AppID
addappid(271590)
-- Main Depots
addappid(271591, 1, "baebeedec48b33c68a322fea0cbaa8d023d1dab4d2870aa909b82c33caa53941")
addappid(271592, 1, "e34313f0ec133a608e636cf04fd879d3ac1e8e10af38542436940be1b6834bee")
addappid(271593, 1, "71b57be5c50e5fbc819068a5bf31db42b653f1c75d88307da682ff0d5cae9457")
addappid(271594, 1, "ae7ed6931a136d41d3aae146563368eb3b3e4e60963344f3f426c0abc74bbdab")
addappid(271595, 1, "6dc0d2ce6b9dc96469ff792f6a607f759f0abd851d496cac73d71cd145c70b4d")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1899671, 1, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")

--# 284160 - BeamNG.drive
-- Main AppID
addappid(284160)
-- Main Depots
addappid(284161, 1, "0e77f1cd7bb3169d9885cc26c7d2ef9fffc02c8c49671bec7b7308dd6cf86229")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

--# 3241660 - R.E.P.O.
-- Main AppID
addappid(3241660)
-- Main Depots
addappid(3241661, 1, "0a0fcffb2de6fb0fa6caff076a5a8cb960903d17320968d5c042fd5a4f9ad2ad")

--# 359550 - Tom Clancy's Rainbow Six Siege
-- Main AppID
addappid(359550)
-- Main Depots
addappid(359551, 1, "b13d0908374e12054e73230c57da5d674dfe45cffe6ba7e11b3f1a8b155938d0") -- (windows, 64-bit)
addappid(359552, 1, "7ac5abea21774ab3f61f79c615ac2dcea23f29073d0c01dea6a6cb4ee74b139a") -- English
addappid(359553, 1, "dcdffceeb418989a4f36985e8ca53f39ff645ec2796964f180dc81d30c3abb57") -- French
addappid(359554, 1, "e75821ffe2ed656753400063f950ce4cb826402068521457bf4328da4072061f") -- Italian
addappid(359555, 1, "58c19a27059a9f1a7bec9fcc4257c41824d4da15f1d0e5df4dae88db684b95b9") -- German
addappid(359556, 1, "f1e2d36dcce0720d25bcfd1ac0c62e70ce0ec3420c4a304419c5c6f0d5688250") -- Spanish
addappid(359557, 1, "50c1ed38ac79bd6e50e75af4cadfa7563ec5cf34781069a6d54695319a03f22b") -- Brazilian
addappid(359558, 1, "010466c630ef6a7c57602b43cec3cc1bf807dfe28a204cfe954ebe28c5c2f14b") -- Polish
addappid(377230, 1, "4c27904751b7ea50cd50b694e4dab0544b357f031327578056f950ec9351c249") -- Dutch
addappid(377231, 1, "0ded8d40d5ed40dbe85c706e4f9d19ffcc159a18ffebce8ba7158eacc3667445") -- Czech
addappid(377232, 1, "1b7a8fa90248e348e1a8d663b6c6566d8c99f6cf01a9ccadd36234a199578962") -- Koreana
addappid(377233, 1, "769c92369ff86fc0fc910a4fa49eb06e3677dff11d50f1330e02a69cfee2e5f1") -- Tchinese
addappid(377234, 1, "c3451634ddea46eae104112a888d041e515f19dd2a838bc5bca500bd8e721d0a") -- Schinese
addappid(377235, 1, "761401671eac7db5677078a194ed11aa43f68bf5cf225e4d53fe8881aa7f44f4") -- Japanese
addappid(377236, 1, "39911d0cd8ce120bb15b2788d54b53ff9925890f198980b595af8ddbf1be1614") -- Russian
addappid(377237, 1, "55e7ea1db9a23f549c35553adb88ac3f97c1fc5f649df1515f5fa1dde7f501a6")
addappid(377238, 1, "63b36db42d50aeac71f9975e2a3bd2ff7a6829efccfeca5983a51b6220e489b3")
addappid(377241, 1, "b1b85afe38896b9d52eb09413f94001a276abec9ed7f7f758934689537e0b36c") -- Arabic
addappid(377242, 1, "a04080ed1ad50d35d6ed2b09d0296cff22ceeb6c6b4cfe60eef1eea0ce465aa0") -- Thai
addappid(377243, 1, "88c8068f4ccb473a741dc1dc784c46b9c3344cc9f30c185b02c5b8ab90baa6fb") -- Latam
addappid(377244, 1, "5761e0144b96152c29d60795e453237cf72af7d4b22079f4b4aade28e5fa8112") -- Turkish
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

--# 381210 - Dead by Daylight
-- Main AppID
addappid(381210)
-- Main Depots
addappid(381211, 1, "66477a849ed619510d127ff3f05d4d37b38a04fd7074654337053dfe817798ca") -- (windows)
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

--# 393380 - Squad
-- Main AppID
addappid(393380)
-- Main Depots
addappid(393381, 1, "d11ff0e6b7d56d9c48173256141f75daf1a14f85f6aac9e09d45d05ef7ef935d") -- (windows, 64-bit)
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

--# 550 - Left 4 Dead 2
-- Main AppID
addappid(550)
-- Main Depots
addappid(551, 1, "133d1039d438364b5569e91221c10fcd640f141d7700c921c02721ebe87c0459")
addappid(552, 1, "2585a22b53c3e040982897d140378d942a22994ffae3ae2085eddf36af94f84d")
addappid(553, 1, "7bc7ab0b0631017e69adc7251eed912215e5ec3629c4e493aed3d59f7647e206") -- (macos)
addappid(554, 1, "0c3a5e0ba83eb05f47677cb62ca99c7066627aa92de37c4ebde5de2f57b63b91") -- (linux)
addappid(555, 1, "ba7293680729c4c2f0335c1eb7e63230a542519312576e0a2da68072b247cbad")
addappid(556, 1, "fe84c8d4b2c27f6155d890d88f0621f11f094610f3c90b0c47f896daddf75e19") -- French
addappid(557, 1, "4a93866c750e2a770cad19228d2659175631748b443f8813b0b60e652a9a00ef") -- German
addappid(558, 1, "b118e5db5c1f6b7671ed8b832dcb8826cc50b86018c97d995a752f4419757c50") -- Spanish
addappid(559, 1, "aa6a7da182c33f764eb15b5f323b9806273e9fed6c8b60b32e4577b0b5e0d339") -- Russian

--# 553850 - HELLDIVERS 2
-- Main AppID
addappid(553850)
-- Main Depots
addappid(553851, 1, "6b40282b237b0cafc4d89014b5ec5f925f9aaa02f2d37f4d956acffdde2e0219") -- (windows, 64-bit)
addappid(553853, 1, "5422d63966f1d6febad8f7e2d1bc3a1640844ae17bae7fc242dc6c1f97b99f3a")
addappid(553854, 1, "43e8d494c23afa2317d5826d1ee2d87cf5657f1ce353df53190884b375a35ddd")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

--# 594650 - Hunt: Showdown 1896
-- Main AppID
addappid(594650)
-- Main Depots
addappid(594651, 1, "2b731d9a42ee11b0f9a51d4aea2c779a2c1943f0ca0027bf38529240e3fd70e4") -- (windows, 64-bit)
addappid(594652, 1, "a8a0c9b88ad0802d43ca2c0d3b8dd40d95a480ddec25ddbc6d154f1b268da0b2") -- (windows, 64-bit)
addappid(594653, 1, "3ff39c9a082647ddfb27213a069c8fb08fd4161798aba12e5dd30cf535b99bb1") -- (windows, 64-bit)
addappid(594654, 1, "8b77c5e77de5ce174135da1a533aa4314f18efb1fd5c358665192adddd8b3f92") -- (windows, 64-bit)
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

--# 70 - Half-Life
-- Main AppID
addappid(70)
-- Main Depots
addappid(1, 1, "b465d45ab2a7c396f7d1c08a6644e68529ec86b14da77e18588abbbcd2412060")
addappid(2, 1, "fd681c065529f5ee95e920321a780a9290f8f31ef51c232ccb3e98d27e132ebc") -- (windows)
addappid(3, 1, "d249f7d93387a793ed021f0e2314ad0cea0d6aef0b0881c3b725a33deec37d59")
addappid(6, 1, "cd3d8b6f23fb863aea4d6789a53dd58dcf284141860e893e8e580d1988d93d3c")
addappid(8, 1, "20af1043db56d6408ddd965580e1269005b6e04f81c3676d155174f73099da95") -- (linux)
addappid(9, 1, "68c92cf2532cdc6e0b7a9d2783b473b6d16bac72218badf68d7be9b033076096") -- (macos)
addappid(71, 1, "71d9ddf78d068fed9320d6fcf7733b62e6957de71a5a14bfa9620401e97d3829")
addappid(72, 1, "bbc1a14b0c63025aece7d9c3b5a98089205580f321bb5edf6b5f00d368c6face") -- French
addappid(73, 1, "9604a5ba9ad4b580269d5362e201d217cdd9d268bf1098e2c6beb0c5ade020d3") -- Italian
addappid(74, 1, "49d573f303205df2316749a6ede6725b74651fae3e845494b88ac3d0022a2857") -- German
addappid(75, 1, "1339202607b6485322859fc1f045c6790bbc470a2d3bb8158aa94b06da31f9bb") -- Spanish
addappid(77, 1, "793780217977cc3a005dc4410e963c980137e4faca4442f92dc41ab56af96983") -- Schinese
addappid(78, 1, "39f04a0cc8cffae8023eff1e3e933680681997409823942a5f0f2899d2d2c4b2") -- Koreana
addappid(79, 1, "019e1cb0950e060fb992001657a444fe03cbc4984081e0d1d9a6505259a7a7e7") -- Tchinese
addappid(96, 1, "aa927e7fc0b2d0ff4a2b681657e816ef56995ec76aa99069ebdc1b01d8d226af")
addappid(141, 1, "0d85b74e163cceabf3651fdd6084585587461f6f7735c37eef875634fc6886cb") -- Russian
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

--# 739630 - Phasmophobia
-- Main AppID
addappid(739630)
-- Main Depots
addappid(739631, 1, "a0af61717bae449e5db4a1cc6eb68d7604ac3a8e05ff5226faa14b5be67d640c")
-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

--# 892970 - Valheim
-- Main AppID
addappid(892970)
-- Main Depots
addappid(892971, 1, "fb041c748eb3303b0bb18fbad3b813d19052060d14953e0d7d735943075833fd") -- (linux)
addappid(892972, 1, "10d286383a9248b6de0c8a160231b4d6332bce1da1fce424d4156329dda3ecf6") -- (windows)
addappid(892973, 1, "6c4d88d54997dcc4234f7ed792e946c0386a6c9a4f242a2bc8c89b49d50f3975") -- (macos)
